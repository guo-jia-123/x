module.exports = {
  LEVEL_COLOR: {
    "error": "\033[31;1;49m",
    "debug": "\033[36;49m",
    "log": "\033[32;49m",
    "warn": "\033[33;49m",
    "#underline": "\033[2;4m",
    "#end": "\033[0m"
  }
};
