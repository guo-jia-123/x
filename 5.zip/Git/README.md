# Git使用教程

windows Git： [windows Git教程](http://ask.dcloud.net.cn/article/35247)

mac Git： [mac Git教程](http://ask.dcloud.net.cn/article/35248)

### Git 插件配置

1. 点击菜单【工具】-->【外部命令】-->【git插件】-->【插件配置】
2. 关于插件配置文件package.json

```
{
	"id":"GIT_CLONE",	//命令ID
	"name":"git clone 克隆",	//外部命令显示名称
	"command":["${programPath}", "/command:clone"],	//执行的命令，${programPath}表示检测到的可执行程序的路径
	"key":"",	//快捷键
	"showInParentMenu":false,	//是否显示在上一级菜单中
	"onDidSaveExecution": false,	//是否保存时执行
	"isBackground": true
}
```

备注：修改配置后，重启HBuilderX才能生效